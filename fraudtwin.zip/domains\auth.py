﻿import streamlit as st
from . import database
from .storage import load_persistent_history, load_investigation_history


def initialize_auth():
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False

    if "user_id" not in st.session_state:
        st.session_state.user_id = None

    if "username" not in st.session_state:
        st.session_state.username = ""

    if "role" not in st.session_state:
        st.session_state.role = "Fraud Analyst"

    if "confirm_logout" not in st.session_state:
        st.session_state.confirm_logout = False

    if "page" not in st.session_state:
        st.session_state.page = "landing"

    if "show_google_chooser" not in st.session_state:
        st.session_state.show_google_chooser = False


def perform_logout():
    st.session_state.authenticated = False
    st.session_state.user_id = None
    st.session_state.username = ""
    st.session_state.role = "Fraud Analyst"
    st.session_state.full_name = ""
    st.session_state.email = ""
    st.session_state.confirm_logout = False
    st.session_state.risk_history = []
    st.session_state.investigation_history = []
    st.session_state.investigation_case = None
    st.session_state.analyzed = False
    st.session_state.analysis_data = None
    st.session_state.twin_result = None
    st.session_state.attack_result = None
    st.session_state.ai_result = None
    st.session_state.show_google_chooser = False
    st.session_state.page = "landing"
    st.rerun()


def request_login(username, password):
    user = database.authenticate_user(username, password)
    if user:
        st.session_state.authenticated = True
        st.session_state.user_id = user["id"]
        st.session_state.username = user["username"]
        st.session_state.full_name = user["full_name"] or user["username"]
        st.session_state.email = user["email"] or ""
        st.session_state.role = user["role"] or "Fraud Analyst"
        st.session_state.appearance = user["appearance"] or "Dark"
        st.session_state.notifications = bool(user["notifications"])
        st.session_state.risk_view = user["risk_view"] or "Risk Score"

        st.session_state.risk_history = load_persistent_history()
        st.session_state.investigation_history = load_investigation_history()
        st.session_state.investigation_case = None
        st.session_state.analyzed = False
        st.session_state.analysis_data = None
        st.session_state.show_google_chooser = False

        st.session_state.page = "Home"
        st.rerun()
    else:
        st.error("Invalid username or password.")


def sign_in_google_account(email, display_name):
    """Signs into a specific Google account with isolated workspace."""
    user = database.get_or_create_google_user(email, display_name)
    st.session_state.authenticated = True
    st.session_state.user_id = user["id"]
    st.session_state.username = user["username"]
    st.session_state.full_name = user["full_name"]
    st.session_state.email = user["email"]
    st.session_state.role = user["role"]
    st.session_state.appearance = user["appearance"] or "Dark"
    st.session_state.notifications = bool(user["notifications"])
    st.session_state.risk_view = user["risk_view"] or "Risk Score"

    st.session_state.risk_history = load_persistent_history()
    st.session_state.investigation_history = load_investigation_history()
    st.session_state.investigation_case = None
    st.session_state.analyzed = False
    st.session_state.analysis_data = None
    st.session_state.show_google_chooser = False

    st.session_state.page = "Home"
    st.rerun()


def request_signup(username, password, full_name, email, phone_number):
    try:
        user = database.create_user(
            username=username,
            password=password,
            full_name=full_name,
            email=email,
            phone_number=phone_number,
            role="Fraud Analyst"
        )
        st.session_state.authenticated = True
        st.session_state.user_id = user["id"]
        st.session_state.username = user["username"]
        st.session_state.full_name = user["full_name"] or user["username"]
        st.session_state.email = user["email"] or ""
        st.session_state.role = user["role"] or "Fraud Analyst"
        st.session_state.appearance = user["appearance"] or "Dark"
        st.session_state.notifications = True
        st.session_state.risk_view = "Risk Score"

        st.session_state.risk_history = []
        st.session_state.investigation_history = []
        st.session_state.investigation_case = None
        st.session_state.analyzed = False
        st.session_state.analysis_data = None
        st.session_state.show_google_chooser = False

        st.session_state.page = "Home"
        st.rerun()
    except Exception as e:
        st.error(str(e))


def inject_auth_styles():
    st.markdown(
        """
        <style>
        .auth-brand {
            display: inline-block;
            color: #c084fc;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 2.5px;
            margin-bottom: 18px;
            padding: 5px 14px;
            border: 1px solid rgba(168, 85, 247, 0.35);
            border-radius: 999px;
            background: rgba(168, 85, 247, 0.08);
        }

        .auth-title {
            font-size: 40px;
            font-weight: 800;
            line-height: 1.18;
            margin-bottom: 14px;
            color: #f5f3ff;
            letter-spacing: -0.8px;
        }

        .auth-subtitle {
            color: #a8a2ba;
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 26px;
            max-width: 440px;
        }

        .feature-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            margin-bottom: 10px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.06);
            max-width: 420px;
            transition: all 0.2s ease;
        }

        .feature-row:hover {
            background: rgba(168, 85, 247, 0.08);
            border-color: rgba(168, 85, 247, 0.25);
            transform: translateX(4px);
        }

        .feature-num {
            font-size: 11px;
            font-weight: 700;
            color: #a855f7;
            background: rgba(168, 85, 247, 0.15);
            border-radius: 6px;
            padding: 4px 8px;
            min-width: 26px;
            text-align: center;
        }

        .feature-label {
            color: #e5e1f0;
            font-size: 14px;
            font-weight: 500;
        }

        .auth-card-wrapper {
            background: rgba(255, 255, 255, 0.035);
            border: 1px solid rgba(255, 255, 255, 0.09);
            border-radius: 18px;
            padding: 26px 26px 22px 26px;
            backdrop-filter: blur(14px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
        }

        .auth-divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: #7a7288;
            font-size: 11.5px;
            font-weight: 600;
            margin: 16px 0;
        }

        .auth-divider::before, .auth-divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .auth-divider::before { margin-right: 12px; }
        .auth-divider::after { margin-left: 12px; }

        .google-account-card {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.09);
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .google-account-card:hover {
            border-color: #a855f7;
            background: rgba(168, 85, 247, 0.08);
        }

        .google-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #4285F4;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            margin-right: 12px;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def show_auth_page():
    initialize_auth()
    inject_auth_styles()

    left, right = st.columns([1.2, 1], gap="large")

    with left:
        st.markdown(
            '<div class="auth-brand">SECURE ENTERPRISE AUTHENTICATION</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            """
            <div class="auth-title">
                Single sign-on<br>
                or verified<br>
                <span style="background: linear-gradient(135deg, #c084fc, #a855f7);
                             -webkit-background-clip: text;
                             background-clip: text;
                             color: transparent;">workspace.</span>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div class="auth-subtitle">'
            'Sign in to access your isolated risk intelligence dashboard, '
            'review transaction telemetry, run stress simulations, and manage investigations.'
            '</div>',
            unsafe_allow_html=True,
        )

        features = [
            ("01", "Tenant Isolation with Zero Cross-User Leakage"),
            ("02", "Multi-Account Google OAuth Profile Switching"),
            ("03", "Cryptographic PBKDF2 Password Recovery"),
            ("04", "Full Audit Trail for Compliance Operations"),
        ]

        feature_html = ""
        for num, label in features:
            feature_html += (
                f'<div class="feature-row">'
                f'<div class="feature-num">{num}</div>'
                f'<div class="feature-label">{label}</div>'
                f'</div>'
            )

        st.markdown(feature_html, unsafe_allow_html=True)

    with right:
        st.markdown('<div class="auth-card-wrapper">', unsafe_allow_html=True)

        # ----------------------------------------------------
        # GOOGLE ACCOUNT CHOOSER VIEW
        # ----------------------------------------------------
        if st.session_state.get("show_google_chooser", False):
            st.markdown(
                """
                <div style="text-align:center; margin-bottom:16px;">
                    <div style="font-size:26px;">🌐</div>
                    <div style="font-size:20px; font-weight:700; color:#f5f3ff;">Choose an account</div>
                    <div style="color:#948da3; font-size:13px;">to continue to FraudTwin Workspace</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Account 1: Personal
            c1, c2 = st.columns([4, 1])
            with c1:
                st.markdown(
                    """
                    <div style="display:flex; align-items:center;">
                        <div class="google-avatar" style="background:#4285F4;">A</div>
                        <div>
                            <div style="color:#f5f3ff; font-weight:700; font-size:14px;">Alex Rivers (Personal)</div>
                            <div style="color:#948da3; font-size:12px;">alex.rivers@gmail.com</div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with c2:
                if st.button("Select", key="pick_google_acc_1", use_container_width=True):
                    sign_in_google_account("alex.rivers@gmail.com", "Alex Rivers")

            st.markdown("<div style='height:6px;'></div>", unsafe_allow_html=True)

            # Account 2: Enterprise
            c3, c4 = st.columns([4, 1])
            with c3:
                st.markdown(
                    """
                    <div style="display:flex; align-items:center;">
                        <div class="google-avatar" style="background:#34A853;">S</div>
                        <div>
                            <div style="color:#f5f3ff; font-weight:700; font-size:14px;">Alex Rivers (SecOps Lead)</div>
                            <div style="color:#948da3; font-size:12px;">alex.secops@enterprise.corp</div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with c4:
                if st.button("Select", key="pick_google_acc_2", use_container_width=True):
                    sign_in_google_account("alex.secops@enterprise.corp", "Alex Rivers (SecOps)")

            st.markdown("<div class='auth-divider'>OR ENTER ANOTHER GOOGLE ACCOUNT</div>", unsafe_allow_html=True)

            with st.expander("Use another Google account", expanded=False):
                custom_g_name = st.text_input("Display Name", placeholder="e.g. Jordan Smith", key="custom_g_name")
                custom_g_email = st.text_input("Google Email", placeholder="jordan@gmail.com", key="custom_g_email")
                if st.button("Sign In with This Account", type="primary", use_container_width=True, key="submit_custom_google"):
                    if not custom_g_email or "@" not in custom_g_email:
                        st.error("Please enter a valid Google email.")
                    else:
                        sign_in_google_account(custom_g_email, custom_g_name or custom_g_email.split("@")[0])

            st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
            if st.button("← Cancel & Return to Login", use_container_width=True, key="cancel_google_chooser"):
                st.session_state.show_google_chooser = False
                st.rerun()

        # ----------------------------------------------------
        # STANDARD AUTH TABS VIEW
        # ----------------------------------------------------
        else:
            st.markdown(
                '<div style="font-size:22px; font-weight:700; color:#f5f3ff; margin-bottom:4px;">'
                'Welcome to FraudTwin</div>'
                '<div style="color:#948da3; font-size:13px; margin-bottom:16px;">'
                'Sign in to your private workspace or create an account.</div>',
                unsafe_allow_html=True,
            )

            # Trigger Google Chooser
            if st.button("🌐 Continue with Google", use_container_width=True, key="auth_google_trigger"):
                st.session_state.show_google_chooser = True
                st.rerun()

            st.markdown('<div class="auth-divider">OR CONTINUE WITH CREDENTIALS</div>', unsafe_allow_html=True)

            login_tab, create_tab, forgot_tab = st.tabs(["Sign In", "Create Account", "Forgot Password"])

            # ----------------------------------------------------
            # TAB 1: SIGN IN
            # ----------------------------------------------------
            with login_tab:
                username = st.text_input("Username or Email", placeholder="Enter username or email", key="login_username")
                password = st.text_input("Password", type="password", placeholder="Enter your password", key="login_password")

                if st.button("Sign In to Workspace", use_container_width=True, key="sign_in_button"):
                    if not username or not password:
                        st.error("Please enter your username and password.")
                    else:
                        request_login(username, password)

            # ----------------------------------------------------
            # TAB 2: CREATE ACCOUNT (WITH EMAIL & PHONE)
            # ----------------------------------------------------
            with create_tab:
                new_username = st.text_input("Username", placeholder="e.g. jdoe_analyst", key="create_username")
                new_fullname = st.text_input("Full Name", placeholder="e.g. John Doe", key="create_fullname")
                new_email = st.text_input("Email Address", placeholder="john.doe@company.com", key="create_email")
                new_phone = st.text_input("Phone Number", placeholder="+91 98765 43210", key="create_phone")
                new_password = st.text_input("Password", type="password", placeholder="Create a secure password", key="create_password")
                confirm_password = st.text_input("Confirm Password", type="password", placeholder="Confirm password", key="confirm_password")

                if st.button("Create Account", type="primary", use_container_width=True, key="create_account_button"):
                    if not new_username or not new_password or not confirm_password:
                        st.error("Username and passwords are required.")
                    elif not new_email or "@" not in new_email:
                        st.error("Please enter a valid email address.")
                    elif not new_phone:
                        st.error("Please enter your contact phone number.")
                    elif new_password != confirm_password:
                        st.error("Passwords do not match.")
                    elif len(new_password) < 6:
                        st.error("Password must be at least 6 characters.")
                    else:
                        request_signup(new_username, new_password, new_fullname or new_username, new_email, new_phone)

            # ----------------------------------------------------
            # TAB 3: FORGOT PASSWORD RECOVERY
            # ----------------------------------------------------
            with forgot_tab:
                st.caption("Enter your registered username or email to recover and reset credentials.")
                reset_account = st.text_input("Username or Registered Email", placeholder="user@company.com", key="reset_account_input")
                reset_new_pwd = st.text_input("New Password", type="password", placeholder="Enter new password", key="reset_new_pwd_input")
                reset_confirm_pwd = st.text_input("Confirm New Password", type="password", placeholder="Confirm new password", key="reset_confirm_pwd_input")

                if st.button("Reset Password", use_container_width=True, key="reset_pwd_btn"):
                    if not reset_account or not reset_new_pwd or not reset_confirm_pwd:
                        st.error("Please fill in all recovery fields.")
                    elif reset_new_pwd != reset_confirm_pwd:
                        st.error("New passwords do not match.")
                    elif len(reset_new_pwd) < 6:
                        st.error("Password must be at least 6 characters.")
                    else:
                        ok, msg = database.reset_user_password(reset_account, reset_new_pwd)
                        if ok:
                            st.success(msg)
                        else:
                            st.error(msg)

        st.markdown('</div>', unsafe_allow_html=True)
